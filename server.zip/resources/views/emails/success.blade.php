<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>
<body>
<p>Hello,</p>
<p>
    Thanks for Registered on Task Tracker.
    I am sure this is your email <span>{{ $email }}</span><br>
    We love you!!!
</p>
<p>
    Admin Officer| Task Tracker
    <br>
    Thanks
</p>
</body>
</html>