@extends('layouts.app')

@section('content')

 <img src="images\task.jpg" class="img-responsive">
@endsection