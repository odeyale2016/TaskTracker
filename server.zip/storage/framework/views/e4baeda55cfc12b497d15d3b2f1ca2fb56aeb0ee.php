<?php $__env->startSection('title','Edit Task'); ?>

<?php $__env->startSection('content'); ?>

 
   <section class="content">
        

            <!-- Widgets -->
             
            <!-- #END# Widgets -->
            <!-- CPU Usage -->
            <div class="row">
                            <div class="col-sm-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Edit Task</h4>
                                    <ol class="breadcrumb float-right">
                                        <li class="breadcrumb-item"><a href="/dashboard">Dashboard</a></li>
                                        <li class="breadcrumb-item"><a href="tasks/create">Edit Task</a></li>
                                    </ol>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-12">
                                <div class="card-box">
                                    <h4 class="m-t-0 header-title">Edit Task</h4>

                                    <div class="row">
                                        <div class="col-12">
                                            <div class="p-20">
                                                <form action="/admin/tasks/<?php echo e($tasks->id); ?>"" class="form-horizontal" role="form" method="POST" enctype="multipart/form-data">
                                                    <?php echo e(csrf_field()); ?>


                                                     <div class="form-group row">
                                                 <input type="hidden" name="_method" value="PUT">
                                                        <label class="col-2 col-form-label">Title</label>
                                                        <div class="col-10">
                                                            <input type="text" name="title" value="<?php echo e($tasks->title); ?>" class="form-control">
                                                        </div>
                                                    </div>
                                                     <div class="form-group row">
                                                        <label class="col-2 col-form-label">Deadline</label>
                                                        <div class="col-10">
                                                            <input type="text" name="deadline" value="<?php echo e($tasks->deadline); ?>" class="form-control">
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-2 col-form-label">Assign Task To</label>
                                                        <div class="col-md-10">
                                                            <select name="user_id" class="form-control">
                                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-2 col-form-label">Status</label>
                                                        <div class="col-10">
                                                            <select type="text" name="status" class="form-control" >
                                                            <option selected style="background-color:red"  value="Not Treated">Not Treated</option>
                                                            <option style="background-color:orange"  value="Pending">Pending</option>
                                                            <option style="background-color:green" value="Completed">Completed</option>   
                                                            </select>
                                                        </div>
                                                    </div>
                                                      <div class="form-group row">
                                                        <label class="col-2 col-form-label">Progress</label>
                                                        <div class="col-10">
                                                            <input type="text" name="progress" value="<?php echo e($tasks->progress); ?>" class="form-control">
                                                        </div>
                                                    </div>
                                                      
                                                      
                                                    
                                                    
                                                    <div class="form-group row">
                                                        <label class="col-2 col-form-label">Milestones</label>
                                                        <div class="col-10">
                                                            <textarea class="form-control" name="milestone" rows="5">
                                                                <?php echo e($tasks->body); ?>

                                                            </textarea>
                                                        </div>
                                                    </div>
                                                  

                                                     

                                                     

                                                    <div class="col-md-2" align="center">
                                                        <button type="submit" class="btn btn-primary">Update</button>

                                                     <button type="reset" class="btn btn-danger pull-right">Reset</button>
                                                    </div>
                                                     

                                                </form>
                                            </div>
                                        </div>

                                    </div>
                                    <!-- end row -->

                                </div> <!-- end card-box -->
                            </div><!-- end col -->
                        </div>
                        <!-- end row -->
 
<?php if(count($errors)): ?>
<div class="alert alert-danger">
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php echo e($error); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
</div></center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>