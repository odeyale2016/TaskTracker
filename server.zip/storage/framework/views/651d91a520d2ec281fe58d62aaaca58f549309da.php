<?php $__env->startSection('content'); ?>

 <img src="images\task.jpg" class="img-responsive">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>