<?php $__env->startSection('title','Task List'); ?>

<?php $__env->startSection('content'); ?>

  <section class="content">
        

            <!-- Widgets -->
            
            <!-- #END# Widgets -->
            <!-- CPU Usage -->
             <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                         
                            <h2>
                                TASK RECORDS
                            </h2>
                            <?php if(Session::has('deleted_task')): ?>
<p class="btn-danger"><?php echo e(session('deleted_task')); ?></p>

<?php endif; ?>
<?php if(Session::has('updated_task')): ?>
<p class="btn-info"><?php echo e(session('updated_task')); ?></p>

<?php endif; ?>
<?php echo e($i=0); ?>

                        </div>

<div class="row">
                            <div class="col-12">
                                <div class="card-box table-responsive">
                                    <h4 class="m-t-0 header-title">List of Tasks</h4>
                                    <p class="text-muted font-14 m-b-30">
                                        
                                    </p>
                                 

                                    <table id="datatable" class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th>#</th>
                                             <th>Task File</th>
                                            <th>Title</th>
                                            <th>Assigned To</th>
                                            <th>Milestone Assigned</th>
                                            <th>Status</th>
                                              <th>Progress</th>
                                              <th>Deadline</th>
                                                <th>CreatedAt</th>
                                             <?php if(auth()->user()->role == 'admin'): ?>
                                            <th>Action</th>
                                                <?php endif; ?>
                                        </tr>
                                        </thead>

                                        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tbody>
                                            <tr>
                                                <td><?php echo e(++$i); ?></td>
                                                <td> <a href="<?php echo e($task->photo ? $task->photo->file : 'http://placeholder.it/400x400'); ?> ">DownloadProjectFile</a> 
                                                    </td>
                                                
                                                <td> <?php echo e($task->title); ?></td>
                                                <td> <?php echo e($task->user->name); ?></td>
                                                <td><?php echo e($task->body); ?></td>
                                                 <td><span id="stat" class="badge "><?php echo e($task->status); ?></span></td>
                                                <td id="pb" class="progress-bar progress-bar-striped" role="progressbar" style="width: <?php echo e($task->progress); ?>px ; height: 25px; margin-top: 10px; margin-right:10px: "   aria-valuemax="100"><?php echo e($task->progress); ?>% done</td>
                                                <td><?php echo e($task->deadline); ?></td>
                                                 <td><?php echo e($task->created_at->diffForHumans()); ?></td>
                                                 
                                                <?php if(auth()->user()->role == 'admin'): ?>
                                    <td><a href="<?php echo e(route('tasks.edit', $task->id)); ?>"><span class="alert alert-primary" style="padding-top:5px; padding-bottom:5px; background-color:#000046; border-bottom:thick solid #000022; border-radius:2px;color:#fff;">Edit</span></a>
             
                                       <div style="height:25px;"></div>
                                     <form class="form-group pull-right" method="post" action="/admin/tasks/<?php echo e($task->id); ?>">
                                        <?php echo e(csrf_field()); ?>

                                        <input type="hidden" name="_method" value="DELETE">
                                    <input type="submit" value="Delete" class="btn btn-danger" style="padding-top:5px; padding-bottom:5px; background-color:#990000; border-bottom:thick solid #000022; border-radius:2px;color:#fff;">
                                        </form> 
                                        </td>
                                                <?php endif; ?>
                                               
     
                                            </tr>
                                            </tbody>
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                            </div>
                        </div>





                        
    </section>
                     

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>