<?php $__env->startSection('title','List of Users'); ?>

<?php $__env->startSection('content'); ?>

  <section class="content">
        

            <!-- Widgets -->
            
            <!-- #END# Widgets -->
            <!-- CPU Usage -->
             <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                         
                            <h2>
                                USER RECORDS
                            </h2>
                            <?php if(Session::has('deleted_user')): ?>
<p class="btn-danger"><?php echo e(session('deleted_user')); ?></p>

<?php endif; ?>
<?php if(Session::has('updated_user')): ?>
<p class="btn-info"><?php echo e(session('updated_user')); ?></p>

<?php endif; ?>
<?php echo e($i=0); ?>

                        </div>

<div class="row">
                            <div class="col-12">
                                <div class="card-box table-responsive">
                                    <h4 class="m-t-0 header-title">List of Users</h4>
                                    <p class="text-muted font-14 m-b-30">
                                        
                                    </p>
                                 

                                    <table id="datatable" class="table table-bordered">
                                        <thead>
                                        <tr>
                                            <th>#</th>
                                             <th>Picture</th>
                                            <th>Fullname</th>
                                            <th>Email</th>
                                            <th>Role</th>
                                              <th>Username</th>
                                                
                                               <th>Phone No</th>
                                                <th>CreatedAt</th>
                                             <?php if(auth()->user()->role == 'admin'): ?>
                                            <th>Action</th>
                                                <?php endif; ?>
                                        </tr>
                                        </thead>

                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tbody>
                                            <tr>
                                                <td><?php echo e(++$i); ?></td>
                                                <td> <img height="100" width="100" src="<?php echo e($user->photo ? $user->photo->file : 'http://placeholder.it/400x400'); ?>" alt="">
                                                    </td>
                                                
                                                <td> <?php echo e($user->name); ?></td>
                                               
                                                <td><?php echo e($user->email); ?></td>
                                                <td><?php echo e($user->role); ?></td>
                                                <td><?php echo e($user->username); ?></td>
                                                <td><?php echo e($user->phone_no); ?></td>
                                                 <td><?php echo e($user->created_at->diffForHumans()); ?></td>
                                                 
                                                <?php if(auth()->user()->role == 'admin'): ?>
                                    <td><a href="<?php echo e(route('users.edit', $user->id)); ?>"><span class="alert alert-primary" style="padding-top:5px; padding-bottom:5px; background-color:#000046; border-bottom:thick solid #000022; border-radius:2px;color:#fff;">Edit</span></a>
             
                                       <div style="height:25px;"></div>
                                     <form class="form-group pull-right" method="post" action="/admin/users/<?php echo e($user->id); ?>">
                                        <?php echo e(csrf_field()); ?>

                                        <input type="hidden" name="_method" value="DELETE">
                                    <input type="submit" value="Delete" class="btn btn-danger" style="padding-top:5px; padding-bottom:5px; background-color:#990000; border-bottom:thick solid #000022; border-radius:2px;color:#fff;">
                                        </form> 
                                        </td>
                                                <?php endif; ?>
                                               
     
                                            </tr>
                                            </tbody>
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                            </div>
                        </div>





                        
    </section>
                     

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>