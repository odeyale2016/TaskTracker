<?php $__env->startSection('title','Edit User'); ?>

<?php $__env->startSection('content'); ?>

 
   <section class="content">
        

            <!-- Widgets -->
             
            <!-- #END# Widgets -->
            <!-- CPU Usage -->
            <div class="row">
                            <div class="col-sm-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Edit User</h4>
                                    <ol class="breadcrumb float-right">
                                        <li class="breadcrumb-item"><a href="/dashboard">Dashboard</a></li>
                                        <li class="breadcrumb-item"><a href="tasks/create">Edit User</a></li>
                                    </ol>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-12">
                                <div class="card-box">
                                    <h4 class="m-t-0 header-title">Edit User</h4>

                                    <div class="row">
                                        <div class="col-12">
                                            <div class="p-20">
                                                <form action="/admin/users/<?php echo e($user->id); ?>"" class="form-horizontal" role="form" method="POST" enctype="multipart/form-data">
                                                    <?php echo e(csrf_field()); ?>


                                                     <div class="form-group row">
                                                 <input type="hidden" name="_method" value="PUT">
                                                        <label class="col-2 col-form-label">FullName</label>
                                                        <div class="col-10">
                                                            <input type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control">
                                                        </div>
                                                    </div>
                                                     <div class="form-group row">
                                                        <label class="col-2 col-form-label">Email</label>
                                                        <div class="col-10">
                                                            <input type="email" name="email" value="<?php echo e($user->email); ?>" class="form-control">
                                                        </div>
                                                    </div>
                                                     <div class="form-group row">
                                                        <label class="col-2 col-form-label">Telephone</label>
                                                        <div class="col-10">
                                                            <input type="text" name="phone_no" value="<?php echo e($user->phone_no); ?>" class="form-control">
                                                        </div>
                                                    </div>
                                                     <div class="form-group row">
                                                        <label class="col-2 col-form-label">Username</label>
                                                        <div class="col-10">
                                                            <input type="text" name="username" value="<?php echo e($user->username); ?>" class="form-control">
                                                        </div>
                                                    </div>
                                                      
                                                     <div class="form-group row">
                                                        <label class="col-2 col-form-label">Gender</label>
                                                        <div class="col-md-10">
                                                            <select name="gender" class="form-control">
                                                                <option >Male</option>
                                                                <option >Female</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                      <div class="form-group row">
                                                        <label class="col-2 col-form-label">Role</label>
                                                        <div class="col-10">
                                                            <input type="text" name="role" value="<?php echo e($user->role); ?>" class="form-control">
                                                        </div>
                                                    </div>
                                                     <div class="form-group row">
                                                        <label class="col-2 col-form-label">Picture</label>
                                                        <div class="col-10">
                                                    <img src="<?php echo e($user->photo ? $user->photo->file : 'http://placeholder.it/400x400.jpg'); ?>"  height="90" width="100" alt="" class="img-resposive img-rounded"> 
                                                    <input name="photo_id" id="photo_id" type="file" multiple />
                                                             
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="form-group row">
                                                         
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-2 col-form-label">Address</label>
                                                        <div class="col-10">
                                                            <textarea class="form-control" name="address" rows="5">
                                                                <?php echo e($user->address); ?>

                                                            </textarea>
                                                        </div>
                                                    </div>
                                                  

                                                     

                                                     

                                                    <div class="col-md-2" align="center">
                                                        <button type="submit" class="btn btn-primary">Update</button>

                                                     <button type="reset" class="btn btn-danger pull-right">Reset</button>
                                                    </div>
                                                     

                                                </form>
                                            </div>
                                        </div>

                                    </div>
                                    <!-- end row -->

                                </div> <!-- end card-box -->
                            </div><!-- end col -->
                        </div>
                        <!-- end row -->
 
<?php if(count($errors)): ?>
<div class="alert alert-danger">
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php echo e($error); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
</div></center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>