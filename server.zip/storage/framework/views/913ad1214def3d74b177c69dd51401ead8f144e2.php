<div id="sidebar-menu">
                        <ul>
                            <li class="menu-title">Main</li>

                            <li>
                                <a href="<?php echo e('\dashboard'); ?>" class="waves-effect waves-primary">
                                    <i class="ti-home"></i><span> Dashboard </span>
                                </a>
                            </li>

                            <?php if(auth()->user()->role == 'admin'): ?>

                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect waves-primary">
                                    <i class="ti-user"></i><span> Setup User </span> 
                                    <span class="menu-arrow"></span>
                                </a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo e(route('users.create')); ?>">Add User</a></li>
                                    
                                    <li><a href="<?php echo e(route('users.index')); ?>">View User</a></li>
                                </ul>
                            </li>

                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect waves-primary">
                                    <i class="ti-paint-bucket"></i> <span> Setup Projects </span>
                                    <span class="menu-arrow"></span>
                                </a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo e(route('projects.create')); ?>">Add Project</a></li>
                                    <li><a href="<?php echo e(route('projects.index')); ?>">View Projects</a></li>
                                    
                                </ul>
                            </li>

                          <?php endif; ?>

                            <li class="has_sub">
                                <a href="javascript:void(0);" class="waves-effect waves-primary">
                                    <i class="ti-menu-alt"></i><span> Setup Tasks </span> 
                                    <span class="menu-arrow"></span> 
                                </a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo e(route('tasks.create')); ?>">Add Tasks</a></li>
                                    <li><a href="<?php echo e(route('tasks.index')); ?>">View Tasks </a></li>
                                   
                                </ul>
                            </li>
                            
                           
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><i class="ti-key"></i><span>
                                        <?php echo e(__('Logout')); ?></span>
                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                            </li>
                        <div class="clearfix"></div>
                    </div>